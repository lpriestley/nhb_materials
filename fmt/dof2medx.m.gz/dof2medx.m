function [tr]=dof2medx(dof,init_sampling,final_sampling,init_centre,final_centre)
%  [tr]=DOF2MEDX(dof,init_sampling,final_sampling,init_centre,final_centre)
%
%	Generates an affine transformation matrix (tr) from the dof list.
%	It requires the initial and final sampling dimension matrices (4x4)
%	 e.g. init_sampling = diag([0.93 0.93 5 1])
%	and the initial and final centre of volume points (normally = (size - 1)/2)
%	 e.g. final_centre = ([172 220 156] - [1 1 1])/2
%	(The dof list can be either 6 or 12 long and in either column or row form)

% fix up alignments - I want column vectors
sz=size(dof);
if (sz(1)<sz(2)),
  dof=dof.';
end
sz=size(init_centre);
if (sz(1)<sz(2)),
  init_centre=init_centre.';
end
sz=size(final_centre);
if (sz(1)<sz(2)),
  final_centre=final_centre.';
end

% fix up 6 dof to 12 dof format
if (length(dof)==6),
  dof=[dof; ones(3,1); zeros(3,1)];
end

transl=dof(1:3);
d2r=pi/180;
ax=dof(4)*d2r;
ay=dof(5)*d2r;
az=dof(6)*d2r;
%rx=make_rot([-ax 0 0],[0 0 0]);
%ry=make_rot([0 -ay 0],[0 0 0]);
%rz=make_rot([0 0 -az],[0 0 0]);
rx=make_rot([ax 0 0],[0 0 0]);
ry=make_rot([0 ay 0],[0 0 0]);
rz=make_rot([0 0 az],[0 0 0]);
rot=rx*ry*rz;
scale=diag([dof(7:9); 1]);
skew=[1 tan(dof(11)*d2r) 0 0; tan(dof(10)*d2r) 1 tan(dof(12)*d2r) 0; ...
       0 0 1 0; 0 0 0 1];
tr=rot*scale*skew;
%tr=skew*scale*rot;
tr(1:3,4)=transl;

% correct everything around the centre of volume
init_move=eye(4);
init_move(1:3,4)=-init_centre;
final_move=eye(4);
final_move(1:3,4)=final_centre;
tr=final_move*inv(final_sampling)*tr*init_sampling*init_move;
tr = eye(4);